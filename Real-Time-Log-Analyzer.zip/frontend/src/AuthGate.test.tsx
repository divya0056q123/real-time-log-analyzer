import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import AuthGate from "./AuthGate";

const auth = vi.hoisted(() => ({
  getToken: vi.fn(() => null as string | null),
  setToken: vi.fn(),
  fetchAuthStatus: vi.fn(),
  fetchCurrentUser: vi.fn(),
  login: vi.fn(),
  register: vi.fn(),
  unauthorizedEvent: "signaldesk:unauthorized",
}));

vi.mock("./api", () => ({
  UNAUTHORIZED_EVENT: auth.unauthorizedEvent,
  fetchAuthStatus: auth.fetchAuthStatus,
  fetchCurrentUser: auth.fetchCurrentUser,
  getToken: auth.getToken,
  login: auth.login,
  register: auth.register,
  setToken: auth.setToken,
}));

vi.mock("./App", () => ({
  default: ({ username, onSignOut }: { username?: string; onSignOut?: () => void }) => (
    <div>
      <span>{username}</span>
      <button onClick={onSignOut}>Sign out</button>
    </div>
  ),
}));

describe("AuthGate", () => {
  afterEach(cleanup);

  beforeEach(() => {
    vi.clearAllMocks();
    auth.getToken.mockReturnValue(null);
    auth.fetchCurrentUser.mockResolvedValue({ username: "newuser" });
    auth.fetchAuthStatus.mockResolvedValue({
      auth_enabled: true,
      needs_setup: false,
      registration_open: true,
    });
  });

  it("lets new users register and signs them into their own account", async () => {
    auth.register.mockResolvedValue({ access_token: "new-token", username: "newuser" });
    render(<AuthGate />);

    fireEvent.click(await screen.findByRole("button", { name: "New to Real-Time Log Analyzer? Create an account" }));
    fireEvent.change(screen.getByLabelText("Username"), { target: { value: "newuser" } });
    fireEvent.change(screen.getByLabelText("Password"), { target: { value: "strong-password" } });
    fireEvent.click(screen.getByRole("button", { name: "Create account" }));

    expect(await screen.findByText("newuser")).toBeTruthy();
    expect(auth.register).toHaveBeenCalledWith("newuser", "strong-password");
  });

  it("restores the authenticated username and signs out", async () => {
    auth.getToken.mockReturnValue("saved-token");
    auth.fetchCurrentUser.mockResolvedValue({ username: "returning-user" });
    render(<AuthGate />);

    expect(await screen.findByText("returning-user")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Sign out" }));

    await waitFor(() => expect(screen.getByRole("heading", { name: "Sign in" })).toBeTruthy());
    expect(auth.setToken).toHaveBeenLastCalledWith(null);
  });

  it("shows local administrator password recovery instructions", async () => {
    render(<AuthGate />);

    fireEvent.click(await screen.findByRole("button", { name: "Forgot password?" }));
    expect(screen.getByRole("heading", { name: "Recover your password" })).toBeTruthy();
    expect(screen.getByText(".\\.venv\\Scripts\\python.exe backend\\scripts\\reset_password.py")).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: "Back to sign in" }));
    expect(screen.getByRole("heading", { name: "Sign in" })).toBeTruthy();
  });
});

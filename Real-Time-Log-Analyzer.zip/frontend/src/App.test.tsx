import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";

const api = vi.hoisted(() => ({
  createRule: vi.fn(),
  fetchAlerts: vi.fn(),
  fetchAnomalies: vi.fn(),
  fetchClusters: vi.fn(),
  fetchLogs: vi.fn(),
  fetchMetrics: vi.fn(),
  fetchRules: vi.fn(),
  fetchServices: vi.fn(),
  fetchTimeline: vi.fn(),
  generateLogs: vi.fn(),
  uploadLogFile: vi.fn(),
  websocketUrl: vi.fn(() => "ws://localhost/ws/logs"),
}));

vi.mock("./api", () => api);

class MockWebSocket {
  static OPEN = 1;
  readyState = 0;
  onopen: (() => void) | null = null;
  onclose: (() => void) | null = null;
  onerror: (() => void) | null = null;
  onmessage: ((event: MessageEvent) => void) | null = null;

  constructor(_url: string) {}

  close() {
    this.readyState = 3;
  }
}

describe("App navigation and account controls", () => {
  beforeEach(() => {
    window.location.hash = "";
    vi.stubGlobal("WebSocket", MockWebSocket);
    api.fetchLogs.mockResolvedValue([]);
    api.fetchMetrics.mockResolvedValue({ total_events: 0, error_rate: 0, events_per_second: 0, by_severity: {} });
    api.fetchTimeline.mockResolvedValue([]);
    api.fetchRules.mockResolvedValue([]);
    api.fetchAlerts.mockResolvedValue([]);
    api.fetchServices.mockResolvedValue([]);
    api.fetchAnomalies.mockResolvedValue([]);
    api.fetchClusters.mockResolvedValue([]);
  });

  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
    vi.clearAllMocks();
  });

  it("opens useful notification, profile, and workspace menus", () => {
    render(<App username="divyanshi" onSignOut={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "Notifications" }));
    expect(screen.getByRole("dialog", { name: "Notifications" })).toBeTruthy();
    expect(screen.getByText(/No recent notifications/)).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: "Account menu" }));
    const accountMenu = screen.getByRole("dialog", { name: "Account" });
    expect(within(accountMenu).getByText("divyanshi")).toBeTruthy();
    expect(within(accountMenu).getByRole("button", { name: "Sign out" })).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: /Shared workspace/ }));
    expect(screen.getByRole("dialog", { name: "Workspace details" })).toBeTruthy();
    expect(screen.getByText(/same logs, alerts, and services/)).toBeTruthy();
  });

  it("updates the selected navigation and breadcrumb when moving between sections", async () => {
    const { container } = render(<App username="divyanshi" />);

    fireEvent.click(screen.getByRole("link", { name: /Alerts/ }));
    await waitFor(() => {
      expect(window.location.hash).toBe("#alerts");
      expect(container.querySelector('nav a[href="#alerts"]')?.getAttribute("aria-current")).toBe("page");
    });
    expect(screen.getByRole("link", { name: "Workspace" })).toBeTruthy();

    fireEvent.click(screen.getByRole("link", { name: "Workspace" }));
    await waitFor(() => {
      expect(window.location.hash).toBe("#overview");
      expect(container.querySelector('nav a[href="#overview"]')?.getAttribute("aria-current")).toBe("page");
    });
  });
});

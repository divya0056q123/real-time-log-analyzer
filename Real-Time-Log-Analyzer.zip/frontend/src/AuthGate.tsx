import { useCallback, useEffect, useState } from "react";
import type { FormEvent } from "react";
import { LoaderCircle, Signal } from "lucide-react";
import App from "./App";
import { UNAUTHORIZED_EVENT, fetchAuthStatus, fetchCurrentUser, getToken, login, register, setToken } from "./api";
import type { AuthStatus } from "./api";

/** Shows the dashboard directly when the server has auth off, otherwise a sign-in / first-run setup form. */
export default function AuthGate() {
  const [status, setStatus] = useState<AuthStatus | null>(null);
  const [token, setTokenState] = useState<string | null>(getToken());
  const [username, setUsername] = useState("");
  const [sessionLoading, setSessionLoading] = useState(Boolean(getToken()));
  const [mode, setMode] = useState<"login" | "register">("login");
  const [showRecovery, setShowRecovery] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState("");

  const loadStatus = useCallback(() => {
    setLoadError("");
    fetchAuthStatus().then(setStatus).catch(() => setLoadError("Cannot reach the log analyzer server."));
  }, []);

  useEffect(() => { loadStatus(); }, [loadStatus]);

  useEffect(() => {
    const onUnauthorized = () => { setTokenState(null); setError("Your session expired. Please sign in again."); };
    window.addEventListener(UNAUTHORIZED_EVENT, onUnauthorized);
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, onUnauthorized);
  }, []);

  useEffect(() => {
    if (!token || !status?.auth_enabled) {
      setSessionLoading(false);
      return;
    }
    let active = true;
    setSessionLoading(true);
    fetchCurrentUser()
      .then((user) => { if (active) setUsername(user.username); })
      .catch(() => {
        if (active) {
          setToken(null);
          setTokenState(null);
          setUsername("");
        }
      })
      .finally(() => { if (active) setSessionLoading(false); });
    return () => { active = false; };
  }, [status?.auth_enabled, token]);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const registering = status?.needs_setup || mode === "register";
      const session = registering ? await register(username, password) : await login(username, password);
      setToken(session.access_token);
      setTokenState(session.access_token);
      setUsername(session.username);
      setPassword("");
      setSessionLoading(false);
      loadStatus();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Sign-in failed.");
    } finally {
      setBusy(false);
    }
  }

  function signOut() {
    setToken(null);
    setTokenState(null);
    setUsername("");
    setError("");
    setMode("login");
  }

  if (loadError) return <div className="auth-screen"><div className="auth-card"><p>{loadError}</p><button className="button button-primary" onClick={loadStatus}>Retry</button></div></div>;
  if (!status) return <div className="auth-screen"><LoaderCircle className="spin" size={22} /></div>;
  if (!status.auth_enabled) return <App />;
  if (token && (sessionLoading || !username)) return <div className="auth-screen"><LoaderCircle className="spin" size={22} /></div>;
  if (token) return <App username={username} onSignOut={signOut} />;

  const setup = status.needs_setup;
  const registering = setup || mode === "register";
  if (showRecovery) return (
    <div className="auth-screen">
      <section className="auth-card recovery-card" aria-labelledby="recovery-title">
        <div className="auth-logo"><Signal size={20} /> Real-Time Log Analyzer</div>
        <h1 id="recovery-title">Recover your password</h1>
        <p>This local installation has no email recovery service. If you administer the computer running the backend, open PowerShell in the project folder and run:</p>
        <code className="recovery-command">.\.venv\Scripts\python.exe backend\scripts\reset_password.py</code>
        <p>Enter your account username, then type and confirm a new password at the hidden prompts. Use the same configured database/environment as the running backend.</p>
        <p className="recovery-note">If you do not have access to the backend computer, ask its administrator to reset your password. Existing sessions may remain active until their 8-hour expiry.</p>
        <button className="button button-secondary" type="button" onClick={() => setShowRecovery(false)}>Back to sign in</button>
      </section>
    </div>
  );
  return (
    <div className="auth-screen">
      <form className="auth-card" onSubmit={(event) => void onSubmit(event)}>
        <div className="auth-logo"><Signal size={20} /> Real-Time Log Analyzer</div>
        <h1>{setup ? "Create the first account" : registering ? "Create your account" : "Sign in"}</h1>
        <p>{setup
          ? "Set up your account to get started. This account manages the shared workspace."
          : registering
            ? "Create an account to access the shared log analyzer workspace."
            : "Enter your credentials to open the shared dashboard."}</p>
        <label>Username<input required minLength={3} maxLength={40} autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} /></label>
        <label>Password<input required type="password" minLength={8} maxLength={128} autoComplete={registering ? "new-password" : "current-password"} value={password} onChange={(event) => setPassword(event.target.value)} /></label>
        {error && <div className="auth-error" role="alert">{error}</div>}
        <button className="button button-primary" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={15} /> : null}{registering ? "Create account" : "Sign in"}</button>
        {!setup && !registering && <button className="auth-switch" type="button" onClick={() => { setError(""); setShowRecovery(true); }}>Forgot password?</button>}
        {!setup && status.registration_open && <button
          className="auth-switch"
          type="button"
          onClick={() => { setMode(registering ? "login" : "register"); setError(""); }}
        >{registering ? "Already have an account? Sign in" : "New to Real-Time Log Analyzer? Create an account"}</button>}
      </form>
    </div>
  );
}

import type {
  AlertRule, Anomaly, LogCluster, LogEvent, LogFilters, Metrics, TimelinePoint, TriggeredAlert,
} from "./types";

export const API_BASE = import.meta.env.VITE_API_URL ?? "/api";

export function buildLogQuery(filters: LogFilters): string {
  const params = new URLSearchParams();
  if (filters.search.trim()) params.set("search", filters.search.trim());
  if (filters.severity) params.set("severity", filters.severity);
  if (filters.service) params.set("service", filters.service);
  if (filters.range !== "all") {
    const minutes = filters.range === "15m" ? 15 : filters.range === "1h" ? 60 : 1440;
    params.set("start", new Date(Date.now() - minutes * 60_000).toISOString());
  }
  params.set("limit", "200");
  return params.toString();
}

const TOKEN_KEY = "signaldesk.token";
export const UNAUTHORIZED_EVENT = "signaldesk:unauthorized";

export function getToken(): string | null {
  try { return window.localStorage.getItem(TOKEN_KEY); } catch { return null; }
}
export function setToken(token: string | null): void {
  try {
    if (token) window.localStorage.setItem(TOKEN_KEY, token);
    else window.localStorage.removeItem(TOKEN_KEY);
  } catch { /* storage unavailable: session lasts until reload */ }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const response = await fetch(`${API_BASE}${path}`, { ...init, headers });
  if (response.status === 401 && token) {
    setToken(null);
    window.dispatchEvent(new Event(UNAUTHORIZED_EVENT));
  }
  if (!response.ok) {
    const detail = await response.json().catch(() => null) as { detail?: string } | null;
    throw new Error(detail?.detail ?? `Request failed (${response.status})`);
  }
  return response.json() as Promise<T>;
}

export const fetchLogs = (filters: LogFilters) =>
  request<LogEvent[]>(`/logs?${buildLogQuery(filters)}`);
export const fetchMetrics = () => request<Metrics>("/metrics");
export const fetchTimeline = () => request<TimelinePoint[]>("/timeline");
export const fetchServices = () => request<string[]>("/services");
export const fetchAnomalies = () => request<Anomaly[]>("/anomalies?minutes=60");
export const fetchClusters = () => request<LogCluster[]>("/clusters?minutes=60&limit=8");
export const fetchRules = () => request<AlertRule[]>("/alerts/rules");
export const fetchAlerts = () => request<TriggeredAlert[]>("/alerts");
export const generateLogs = (count = 12) =>
  request<{ accepted: number }>("/logs/generate?count=" + count, { method: "POST" });
export const createRule = (body: { name: string; threshold: number; window_minutes: number }) =>
  request<AlertRule>("/alerts/rules", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

export async function uploadLogFile(file: File): Promise<{ accepted: number; rejected: number }> {
  const form = new FormData();
  form.append("file", file);
  return request("/logs/upload", { method: "POST", body: form });
}

export function websocketUrl(): string {
  if (import.meta.env.VITE_WS_URL) return import.meta.env.VITE_WS_URL;
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const token = getToken();
  const query = token ? `?token=${encodeURIComponent(token)}` : "";
  return `${protocol}//${window.location.host}/ws/logs${query}`;
}

export interface AuthStatus { auth_enabled: boolean; needs_setup: boolean; registration_open: boolean }
export interface Session { access_token: string; username: string }

export const fetchAuthStatus = () => request<AuthStatus>("/auth/status");
export const fetchCurrentUser = () => request<{ username: string }>("/auth/me");
const authBody = (username: string, password: string): RequestInit => ({
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ username, password }),
});
export const login = (username: string, password: string) =>
  request<Session>("/auth/login", authBody(username, password));
export const register = (username: string, password: string) =>
  request<Session>("/auth/register", authBody(username, password));

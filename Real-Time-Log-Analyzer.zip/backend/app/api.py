import hmac
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, File, Header, HTTPException, Query, Request, UploadFile
from pydantic import ValidationError

from .anomaly import detect_anomalies
from .auth import create_token, hash_password, read_token, verify_password
from .clustering import cluster_events
from .config import MAX_INGEST_BATCH, MAX_UPLOAD_BYTES
from .models import (
    AlertRule, AlertRuleCreate, Anomaly, IngestBatch, IngestResponse, LogCluster, LogEvent,
    Credentials, Metrics, TimelinePoint, TokenResponse, TriggeredAlert,
)
from .parser import parse_line
from .repository import LogRepository, UserExistsError


_DUMMY_PASSWORD_HASH = hash_password("dummy-password", salt=b"signaldesk-dummy-salt")


def require_user(request: Request, authorization: str | None = Header(default=None)) -> str | None:
    """Dependency for dashboard routes: enforced only when AUTH_ENABLED is on."""
    if not request.app.state.auth_enabled:
        return None
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Sign in required", headers={"WWW-Authenticate": "Bearer"})
    username = read_token(authorization[7:].strip(), request.app.state.secret_key)
    if username is None:
        raise HTTPException(status_code=401, detail="Session expired, sign in again", headers={"WWW-Authenticate": "Bearer"})
    return username


router = APIRouter(prefix="/api", dependencies=[Depends(require_user)])  # needs a session when auth is on
public_router = APIRouter(prefix="/api")  # health check and API-key ingestion
auth_router = APIRouter(prefix="/api/auth")


def _repository(request: Request) -> LogRepository:
    return request.app.state.repository


def _as_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


@public_router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/logs", response_model=list[LogEvent])
def get_logs(
    request: Request,
    search: str | None = Query(default=None, max_length=200),
    severity: str | None = Query(default=None, pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL|UNKNOWN)$"),
    service: str | None = Query(default=None, max_length=100),
    start: datetime | None = None,
    end: datetime | None = None,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> list[dict]:
    start = _as_utc(start)
    end = _as_utc(end)
    if start and end and start > end:
        raise HTTPException(status_code=422, detail="start must be earlier than or equal to end")
    return _repository(request).query_logs(
        search=search,
        severity=severity,
        service=service,
        start=start,
        end=end,
        limit=limit,
        offset=offset,
    )


@router.get("/metrics", response_model=Metrics)
def metrics(request: Request) -> dict:
    return _repository(request).get_metrics()


@router.get("/timeline", response_model=list[TimelinePoint])
def timeline(request: Request, minutes: int = Query(default=60, ge=1, le=1440)) -> list[dict]:
    return _repository(request).get_timeline(minutes)


@router.get("/services", response_model=list[str])
def services(request: Request) -> list[str]:
    return _repository(request).list_services()


@router.post("/logs/generate", response_model=IngestResponse)
async def generate_logs(request: Request, count: int = Query(default=20, ge=1, le=500)) -> dict:
    samples = [
        "INFO [api-gateway] [src/routes.py] request completed status=200 latency=42ms",
        "WARNING [worker] [src/jobs.py] retrying delayed task attempt=2",
        "ERROR [payments] [src/checkout.py] payment provider timeout after 5s",
        "DEBUG [auth] [src/token.py] token refreshed successfully",
        "INFO [database] [src/pool.py] connection pool healthy active=8",
    ]
    import random

    lines = [f"{datetime.now(timezone.utc).isoformat()} {random.choice(samples)}" for _ in range(count)]
    accepted, rejected = await request.app.state.ingestor.ingest_lines(lines)
    return {"accepted": accepted, "rejected": rejected, "message": "Generated sample log events."}


@router.post("/logs/upload", response_model=IngestResponse)
async def upload_logs(request: Request, file: UploadFile = File(...)) -> dict:
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".log", ".txt"}:
        raise HTTPException(status_code=415, detail="Only .log and .txt files are supported")
    chunks = bytearray()
    while len(chunks) <= MAX_UPLOAD_BYTES:
        chunk = await file.read(min(64 * 1024, MAX_UPLOAD_BYTES + 1 - len(chunks)))
        if not chunk:
            break
        chunks.extend(chunk)
    await file.close()
    if len(chunks) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"Upload exceeds the {MAX_UPLOAD_BYTES}-byte limit")
    content = bytes(chunks).decode("utf-8", errors="replace")
    lines = content.splitlines()
    accepted, rejected = await request.app.state.ingestor.ingest_lines(lines)
    return {"accepted": accepted, "rejected": rejected, "message": "Log file processed."}


@router.get("/alerts/rules", response_model=list[AlertRule])
def alert_rules(request: Request) -> list[dict]:
    rules = _repository(request).list_rules()
    for rule in rules:
        rule["enabled"] = bool(rule["enabled"])
        rule["created_at"] = datetime.fromisoformat(rule["created_at"])
    return rules


@router.post("/alerts/rules", response_model=AlertRule, status_code=201)
def create_alert_rule(request: Request, rule: AlertRuleCreate) -> dict:
    stored = _repository(request).create_rule(rule)
    stored["enabled"] = bool(stored["enabled"])
    stored["created_at"] = datetime.fromisoformat(stored["created_at"])
    return stored


@router.get("/alerts", response_model=list[TriggeredAlert])
def triggered_alerts(request: Request, limit: int = Query(default=50, ge=1, le=200)) -> list[dict]:
    return _repository(request).list_alerts(limit)


@router.post("/ingest/parse-preview")
def parse_preview(payload: dict) -> dict:
    line = payload.get("line")
    if not isinstance(line, str) or len(line) > 100_000:
        raise HTTPException(status_code=422, detail="line must be text no longer than 100,000 characters")
    try:
        result = parse_line(line)
    except (ValueError, ValidationError) as exc:
        raise HTTPException(status_code=422, detail="Unable to parse log line") from exc
    return result


@router.get("/anomalies", response_model=list[Anomaly])
def anomalies(request: Request, minutes: int = Query(default=60, ge=10, le=1440)) -> list[dict]:
    """Statistically unusual minutes (robust z-score on error and total volume)."""
    points = _repository(request).get_timeline(minutes)
    found = detect_anomalies(points, "errors") + detect_anomalies(points, "total")
    return sorted(found, key=lambda item: item["bucket"], reverse=True)


@router.get("/clusters", response_model=list[LogCluster])
def clusters(
    request: Request,
    minutes: int = Query(default=60, ge=1, le=1440),
    limit: int = Query(default=10, ge=1, le=50),
) -> list[dict]:
    """Group similar messages into templates so thousands of lines become a few patterns."""
    since = datetime.now(timezone.utc) - timedelta(minutes=minutes)
    return cluster_events(_repository(request).logs_since(since), limit)


@public_router.post("/ingest", response_model=IngestResponse, status_code=202)
async def ingest_events(
    request: Request,
    batch: IngestBatch,
    x_api_key: str | None = Header(default=None),
) -> dict:
    """Machine-to-machine ingestion: other applications POST structured events here."""
    api_key: str = request.app.state.ingest_api_key
    if not api_key:
        raise HTTPException(status_code=503, detail="HTTP ingestion is disabled; set INGEST_API_KEY")
    if x_api_key is None or not hmac.compare_digest(x_api_key.encode(), api_key.encode()):
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key")
    if len(batch.events) > MAX_INGEST_BATCH:
        raise HTTPException(status_code=413, detail=f"At most {MAX_INGEST_BATCH} events per request")
    ingestor = request.app.state.ingestor
    await ingestor.ingest_events([event.model_dump() for event in batch.events])
    await ingestor.check_anomalies()
    return {"accepted": len(batch.events), "rejected": 0, "message": "Events ingested."}


@auth_router.get("/status")
def auth_status(request: Request) -> dict:
    """Lets the UI decide whether to show the sign-in screen."""
    repository = _repository(request)
    state = request.app.state
    return {
        "auth_enabled": state.auth_enabled,
        "needs_setup": state.auth_enabled and repository.count_users() == 0,
        "registration_open": state.allow_registration,
    }


@auth_router.post("/register", response_model=TokenResponse, status_code=201)
def register(request: Request, credentials: Credentials) -> dict:
    state, repository = request.app.state, _repository(request)
    if not state.auth_enabled:
        raise HTTPException(status_code=404, detail="Authentication is not enabled")
    first_user = repository.count_users() == 0
    if not first_user and not state.allow_registration:
        raise HTTPException(status_code=403, detail="Registration is closed")
    try:
        password_hash = hash_password(credentials.password)
        user = repository.create_first_user(credentials.username, password_hash) if first_user else None
        if user is None:
            if first_user and not state.allow_registration:
                raise HTTPException(status_code=403, detail="Registration is closed")
            user = repository.create_user(credentials.username, password_hash)
    except UserExistsError as exc:
        raise HTTPException(status_code=409, detail="That username is taken") from exc
    return {"access_token": create_token(user["username"], state.secret_key), "username": user["username"]}


@auth_router.post("/login", response_model=TokenResponse)
def login(request: Request, credentials: Credentials) -> dict:
    state, repository = request.app.state, _repository(request)
    if not state.auth_enabled:
        raise HTTPException(status_code=404, detail="Authentication is not enabled")
    name = credentials.username
    if state.throttle.locked(name):
        raise HTTPException(status_code=429, detail="Too many attempts. Try again in a minute.")
    user = repository.get_user(name)
    stored = user["password_hash"] if user else _DUMMY_PASSWORD_HASH
    if not verify_password(credentials.password, stored) or user is None:
        state.throttle.fail(name)
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    state.throttle.clear(name)
    return {"access_token": create_token(name, state.secret_key), "username": name}


@auth_router.get("/me")
def me(username: str | None = Depends(require_user)) -> dict:
    return {"username": username}

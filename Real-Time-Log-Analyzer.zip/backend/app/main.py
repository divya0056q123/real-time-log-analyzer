from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from . import api
from .alerts import AlertEvaluator
from .auth import LoginThrottle, read_token
from .config import (
    ALLOW_REGISTRATION, AUTH_ENABLED, DATABASE_PATH, DATABASE_URL, INGEST_API_KEY, MAX_INGEST_BODY_BYTES, SAMPLE_LOG_PATH,
    SECRET_KEY, WEBHOOK_URL,
)
from .ingestion import LogIngestor
from .notifier import WebhookNotifier
from .parser import parse_line
from .repository import SQLiteRepository
from .request_limits import RequestBodyLimitMiddleware
from .websocket import EventHub


def create_app(
    database_path=DATABASE_PATH,
    ingest_api_key: str = INGEST_API_KEY,
    auth_enabled: bool = AUTH_ENABLED,
    secret_key: str = SECRET_KEY,
    allow_registration: bool = ALLOW_REGISTRATION,
    database_url: str = DATABASE_URL,
    max_ingest_body_bytes: int = MAX_INGEST_BODY_BYTES,
) -> FastAPI:
    if max_ingest_body_bytes < 1:
        raise ValueError("MAX_INGEST_BODY_BYTES must be positive")
    if auth_enabled and len(secret_key) < 16:
        raise RuntimeError("AUTH_ENABLED requires SECRET_KEY to be set to a random string of 16+ characters")
    if database_url:
        from .postgres_repository import PostgresRepository

        repository = PostgresRepository(database_url)
    else:
        repository = SQLiteRepository(database_path)
    hub = EventHub()
    alerts = AlertEvaluator(repository)
    ingestor = LogIngestor(repository, alerts, hub, WebhookNotifier(WEBHOOK_URL))

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        repository.initialize()
        if repository.count_logs() == 0 and SAMPLE_LOG_PATH.exists():
            samples = SAMPLE_LOG_PATH.read_text(encoding="utf-8").splitlines()
            seeded_at = datetime.now(timezone.utc)
            for index, line in enumerate(samples):
                event = parse_line(line)
                event["timestamp"] = seeded_at - timedelta(seconds=len(samples) - index)
                repository.insert_log(event)
        yield

    app = FastAPI(title="Real-Time Log Analyzer", version="1.0.0", lifespan=lifespan)
    app.state.repository = repository
    app.state.ingest_api_key = ingest_api_key
    app.state.auth_enabled = auth_enabled
    app.state.secret_key = secret_key
    app.state.allow_registration = allow_registration
    app.state.throttle = LoginThrottle()
    app.state.hub = hub
    app.state.ingestor = ingestor
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["*"],
    )
    app.add_middleware(RequestBodyLimitMiddleware, limits={"/api/ingest": max_ingest_body_bytes})
    app.include_router(api.public_router)
    app.include_router(api.auth_router)
    app.include_router(api.router)

    @app.websocket("/ws/logs")
    async def logs_socket(websocket: WebSocket):
        if auth_enabled and read_token(websocket.query_params.get("token", ""), secret_key) is None:
            await websocket.close(code=4401)
            return
        await hub.connect(websocket)
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            await hub.disconnect(websocket)

    return app


app = create_app()

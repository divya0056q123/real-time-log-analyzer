"""PostgreSQL implementation of the same repository interface as SQLiteRepository.

Selected by setting DATABASE_URL (postgresql://user:pass@host:5432/dbname).
Requires ``psycopg[binary]`` (see requirements-postgres.txt). Timestamps are stored as
timestamptz, so time-bucketing uses date_trunc instead of SQLite string slicing.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from .models import AlertRuleCreate
from .repository import UserExistsError


class PostgresRepository:
    def __init__(self, dsn: str):
        try:
            import psycopg
            from psycopg.rows import dict_row
        except ImportError as exc:  # pragma: no cover - depends on optional dependency
            raise RuntimeError("PostgreSQL support needs: pip install -r backend/requirements-postgres.txt") from exc
        self._psycopg = psycopg
        self._dict_row = dict_row
        self.dsn = dsn

    def _connect(self):
        return self._psycopg.connect(self.dsn, row_factory=self._dict_row, autocommit=True)

    def initialize(self) -> None:
        with self._connect() as db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS log_events (
                    id BIGSERIAL PRIMARY KEY,
                    timestamp TIMESTAMPTZ NOT NULL,
                    severity TEXT NOT NULL,
                    service TEXT NOT NULL,
                    source TEXT NOT NULL,
                    message TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON log_events(timestamp);
                CREATE INDEX IF NOT EXISTS idx_logs_severity ON log_events(severity);
                CREATE INDEX IF NOT EXISTS idx_logs_service ON log_events(service);
                CREATE TABLE IF NOT EXISTS alert_rules (
                    id SERIAL PRIMARY KEY,
                    name TEXT NOT NULL,
                    threshold INTEGER NOT NULL,
                    window_minutes INTEGER NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TIMESTAMPTZ NOT NULL
                );
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL
                );
                CREATE TABLE IF NOT EXISTS triggered_alerts (
                    id SERIAL PRIMARY KEY,
                    rule_id INTEGER NOT NULL REFERENCES alert_rules(id),
                    rule_name TEXT NOT NULL,
                    message TEXT NOT NULL,
                    count INTEGER NOT NULL,
                    triggered_at TIMESTAMPTZ NOT NULL
                );
                """
            )

    # ---- logs -------------------------------------------------------------
    def count_logs(self) -> int:
        with self._connect() as db:
            return int(db.execute("SELECT COUNT(*) AS n FROM log_events").fetchone()["n"])

    def insert_log(self, event: dict[str, Any]) -> dict[str, Any]:
        return self.insert_logs([event])[0]

    def insert_logs(self, events: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if not events:
            return []
        with self._connect() as db:
            with db.transaction():
                return [
                    db.execute(
                        "INSERT INTO log_events(timestamp,severity,service,source,message) VALUES(%s,%s,%s,%s,%s) RETURNING *",
                        (event["timestamp"], event["severity"], event["service"], event["source"], event["message"]),
                    ).fetchone()
                    for event in events
                ]

    def query_logs(self, *, search=None, severity=None, service=None, start=None, end=None, limit=100, offset=0):
        clauses: list[str] = []
        params: list[Any] = []
        if search:
            clauses.append("(message ILIKE %s OR service ILIKE %s OR source ILIKE %s)")
            params.extend([f"%{search}%"] * 3)
        if severity:
            clauses.append("severity = %s")
            params.append(severity.upper())
        if service:
            clauses.append("service = %s")
            params.append(service)
        if start:
            clauses.append("timestamp >= %s")
            params.append(start)
        if end:
            clauses.append("timestamp <= %s")
            params.append(end)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.extend([max(1, min(limit, 500)), max(0, offset)])
        with self._connect() as db:
            return db.execute(
                f"SELECT * FROM log_events {where} ORDER BY timestamp DESC, id DESC LIMIT %s OFFSET %s", params
            ).fetchall()

    def logs_since(self, since: datetime, limit: int = 5000) -> list[dict[str, Any]]:
        with self._connect() as db:
            return db.execute(
                "SELECT * FROM log_events WHERE timestamp >= %s ORDER BY timestamp DESC, id DESC LIMIT %s",
                (since, max(1, min(limit, 20000))),
            ).fetchall()

    def get_metrics(self) -> dict[str, Any]:
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=60)
        with self._connect() as db:
            counts = {r["severity"]: int(r["n"]) for r in db.execute("SELECT severity, COUNT(*) AS n FROM log_events GROUP BY severity")}
            recent = int(db.execute("SELECT COUNT(*) AS n FROM log_events WHERE timestamp >= %s", (cutoff,)).fetchone()["n"])
        total = sum(counts.values())
        errors = counts.get("ERROR", 0) + counts.get("CRITICAL", 0)
        return {"total_events": total, "error_rate": errors / total if total else 0.0,
                "events_per_second": recent / 60, "by_severity": counts}

    def get_timeline(self, minutes: int = 60) -> list[dict[str, Any]]:
        end = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        cutoff = end - timedelta(minutes=minutes - 1)
        with self._connect() as db:
            rows = db.execute(
                """SELECT date_trunc('minute', timestamp) AS minute, COUNT(*) AS total,
                   SUM(CASE WHEN severity IN ('ERROR','CRITICAL') THEN 1 ELSE 0 END) AS errors
                   FROM log_events WHERE timestamp >= %s GROUP BY minute ORDER BY minute""",
                (cutoff,),
            ).fetchall()
        counts = {r["minute"].astimezone(timezone.utc): (int(r["total"]), int(r["errors"])) for r in rows}
        points = []
        for index in range(minutes):
            bucket = cutoff + timedelta(minutes=index)
            total, errors = counts.get(bucket, (0, 0))
            points.append({"bucket": bucket, "total": total, "errors": errors})
        average = sum(p["errors"] for p in points) / max(1, len(points))
        threshold = max(3, average * 2.5)
        for p in points:
            p["spike"] = p["errors"] >= threshold and p["errors"] > 0
        return points

    def list_services(self) -> list[str]:
        with self._connect() as db:
            return [r["service"] for r in db.execute("SELECT DISTINCT service FROM log_events ORDER BY service")]

    # ---- alert rules ------------------------------------------------------
    @staticmethod
    def _iso(row: dict[str, Any], *fields: str) -> dict[str, Any]:
        # The API layer expects ISO strings for rule.created_at (as SQLite returns them).
        for field in fields:
            if isinstance(row.get(field), datetime):
                row[field] = row[field].isoformat()
        return row

    def create_rule(self, rule: AlertRuleCreate) -> dict[str, Any]:
        with self._connect() as db:
            row = db.execute(
                "INSERT INTO alert_rules(name,threshold,window_minutes,enabled,created_at) VALUES(%s,%s,%s,%s,%s) RETURNING *",
                (rule.name, rule.threshold, rule.window_minutes, int(rule.enabled), datetime.now(timezone.utc)),
            ).fetchone()
        return self._iso(row, "created_at")

    def list_rules(self) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute("SELECT * FROM alert_rules ORDER BY id DESC").fetchall()
        return [self._iso(r, "created_at") for r in rows]

    def enabled_rules(self) -> list[dict[str, Any]]:
        with self._connect() as db:
            return db.execute("SELECT * FROM alert_rules WHERE enabled=1").fetchall()

    def count_errors_since(self, since: datetime) -> int:
        with self._connect() as db:
            return int(db.execute(
                "SELECT COUNT(*) AS n FROM log_events WHERE severity IN ('ERROR','CRITICAL') AND timestamp >= %s", (since,)
            ).fetchone()["n"])

    def recent_rule_alert(self, rule_id: int, since: datetime) -> bool:
        with self._connect() as db:
            return db.execute(
                "SELECT 1 FROM triggered_alerts WHERE rule_id=%s AND triggered_at >= %s LIMIT 1", (rule_id, since)
            ).fetchone() is not None

    def insert_alert(self, rule: dict[str, Any], count: int) -> dict[str, Any]:
        message = f'{count} errors detected in the last {rule["window_minutes"]} minute(s) (threshold: {rule["threshold"]}).'
        with self._connect() as db:
            return db.execute(
                "INSERT INTO triggered_alerts(rule_id,rule_name,message,count,triggered_at) VALUES(%s,%s,%s,%s,%s) RETURNING *",
                (rule["id"], rule["name"], message, count, datetime.now(timezone.utc)),
            ).fetchone()

    def list_alerts(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as db:
            return db.execute(
                "SELECT * FROM triggered_alerts ORDER BY triggered_at DESC, id DESC LIMIT %s", (max(1, min(limit, 200)),)
            ).fetchall()

    # ---- users ------------------------------------------------------------
    def count_users(self) -> int:
        with self._connect() as db:
            return int(db.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"])

    def create_user(self, username: str, password_hash: str) -> dict[str, Any]:
        try:
            with self._connect() as db:
                return db.execute(
                    "INSERT INTO users(username,password_hash,created_at) VALUES(%s,%s,%s) RETURNING *",
                    (username, password_hash, datetime.now(timezone.utc)),
                ).fetchone()
        except self._psycopg.errors.UniqueViolation as exc:
            raise UserExistsError(username) from exc

    def create_first_user(self, username: str, password_hash: str) -> dict[str, Any] | None:
        with self._connect() as db:
            with db.transaction():
                db.execute("LOCK TABLE users IN EXCLUSIVE MODE")
                if db.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]:
                    return None
                return db.execute(
                    "INSERT INTO users(username,password_hash,created_at) VALUES(%s,%s,%s) RETURNING *",
                    (username, password_hash, datetime.now(timezone.utc)),
                ).fetchone()

    def get_user(self, username: str) -> dict[str, Any] | None:
        with self._connect() as db:
            return db.execute("SELECT * FROM users WHERE username=%s", (username,)).fetchone()

    def update_user_password(self, username: str, password_hash: str) -> bool:
        with self._connect() as db:
            cursor = db.execute(
                "UPDATE users SET password_hash=%s WHERE username=%s",
                (password_hash, username),
            )
            return cursor.rowcount == 1

import os
import secrets
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATABASE_PATH = Path(os.getenv("DATABASE_PATH", PROJECT_ROOT / "data" / "logs.db"))
SAMPLE_LOG_PATH = PROJECT_ROOT / "sample-data" / "application.log"
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(5 * 1024 * 1024)))
# Shared secret that external apps send in the X-API-Key header to POST /api/ingest.
# Leave empty to keep the endpoint disabled.
INGEST_API_KEY = os.getenv("INGEST_API_KEY", "")
# Optional Slack-compatible incoming-webhook URL for alert / anomaly notifications.
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
MAX_INGEST_BATCH = int(os.getenv("MAX_INGEST_BATCH", "1000"))
MAX_INGEST_BODY_BYTES = int(os.getenv("MAX_INGEST_BODY_BYTES", str(10 * 1024 * 1024)))
# Database: SQLite file by default; set DATABASE_URL=postgresql://user:pass@host:5432/db to use PostgreSQL.
DATABASE_URL = os.getenv("DATABASE_URL", "")
# Login. When AUTH_ENABLED=true every dashboard API call needs a bearer token.
AUTH_ENABLED = os.getenv("AUTH_ENABLED", "true").lower() == "true"
SECRET_KEY = os.getenv("SECRET_KEY") or secrets.token_urlsafe(32)
ALLOW_REGISTRATION = os.getenv("ALLOW_REGISTRATION", "true").lower() == "true"

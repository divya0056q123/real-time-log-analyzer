from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

from app.auth import create_token, hash_password, read_token, verify_password
from app.main import create_app
from app.repository import SQLiteRepository
from scripts.reset_password import reset_password

SECRET = "x" * 32
CREDS = {"username": "divyanshi", "password": "correct-horse-1"}


def make(tmp_path, **kwargs):
    kwargs.setdefault("allow_registration", False)
    return TestClient(create_app(tmp_path / "t.db", auth_enabled=True, secret_key=SECRET, **kwargs))


def test_password_and_token_primitives():
    stored = hash_password("secret-password")
    assert verify_password("secret-password", stored) and not verify_password("nope", stored)
    token = create_token("a", SECRET)
    assert read_token(token, SECRET) == "a"
    assert read_token(token, "y" * 32) is None
    assert read_token(create_token("a", SECRET, ttl_seconds=-1), SECRET) is None


def test_auth_requires_a_strong_secret(tmp_path):
    with pytest.raises(RuntimeError):
        create_app(tmp_path / "t.db", auth_enabled=True, secret_key="short")


def test_dashboard_routes_need_a_token_but_health_does_not(tmp_path):
    with make(tmp_path) as client:
        assert client.get("/api/health").status_code == 200
        assert client.get("/api/logs").status_code == 401
        assert client.get("/api/logs", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_first_user_registers_then_registration_closes(tmp_path):
    with make(tmp_path) as client:
        assert client.get("/api/auth/status").json()["needs_setup"] is True
        created = client.post("/api/auth/register", json=CREDS)
        assert created.status_code == 201
        token = created.json()["access_token"]
        assert client.get("/api/logs", headers={"Authorization": f"Bearer {token}"}).status_code == 200
        assert client.get("/api/auth/status").json()["needs_setup"] is False
        other = {"username": "someone", "password": "another-pass-1"}
        assert client.post("/api/auth/register", json=other).status_code == 403


def test_login_success_failure_and_lockout(tmp_path):
    with make(tmp_path) as client:
        client.post("/api/auth/register", json=CREDS)
        ok = client.post("/api/auth/login", json=CREDS)
        assert ok.status_code == 200 and ok.json()["username"] == "divyanshi"
        bad = {**CREDS, "password": "wrong-password"}
        for _ in range(5):
            assert client.post("/api/auth/login", json=bad).status_code == 401
        assert client.post("/api/auth/login", json=bad).status_code == 429
        assert client.post("/api/auth/login", json=CREDS).status_code == 429  # locked even for the right password


def test_duplicate_username_and_weak_password(tmp_path):
    with make(tmp_path, allow_registration=True) as client:
        client.post("/api/auth/register", json=CREDS)
        assert client.post("/api/auth/register", json=CREDS).status_code == 409
        assert client.post("/api/auth/register", json={"username": "newuser", "password": "short"}).status_code == 422


def test_open_registration_allows_new_users_to_join_and_sign_in(tmp_path):
    with make(tmp_path, allow_registration=True) as client:
        first = client.post("/api/auth/register", json=CREDS)
        second_credentials = {"username": "newuser", "password": "another-pass-1"}
        second = client.post("/api/auth/register", json=second_credentials)

        assert first.status_code == second.status_code == 201
        assert client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {second.json()['access_token']}"},
        ).json() == {"username": "newuser"}
        assert client.post("/api/auth/login", json=second_credentials).status_code == 200


def test_first_user_registration_closes_atomically(tmp_path):
    with make(tmp_path) as client:
        first = client.post("/api/auth/register", json=CREDS)
        second = client.post(
            "/api/auth/register",
            json={"username": "another", "password": "another-pass-1"},
        )
        assert first.status_code == 201
        assert second.status_code == 403


def test_concurrent_first_user_creation_allows_only_one_account(tmp_path):
    repository = SQLiteRepository(tmp_path / "t.db")
    repository.initialize()

    def create_user(username):
        return repository.create_first_user(username, "password-hash")

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(create_user, ("first", "second")))
    assert sum(user is not None for user in results) == 1
    assert repository.count_users() == 1


def test_websocket_rejects_missing_token(tmp_path):
    with make(tmp_path) as client:
        token = client.post("/api/auth/register", json=CREDS).json()["access_token"]
        with pytest.raises(WebSocketDisconnect):
            with client.websocket_connect("/ws/logs"):
                pass
        with client.websocket_connect(f"/ws/logs?token={token}"):
            pass


def test_api_key_ingestion_still_works_with_auth_on(tmp_path):
    with make(tmp_path, ingest_api_key="k") as client:
        batch = {"events": [{"message": "hello", "service": "svc"}]}
        assert client.post("/api/ingest", json=batch, headers={"X-API-Key": "k"}).status_code == 202


def test_local_password_reset_updates_password_and_preserves_login(tmp_path):
    repository = SQLiteRepository(tmp_path / "t.db")
    repository.initialize()
    repository.create_user(CREDS["username"], hash_password(CREDS["password"]))

    assert reset_password(repository, CREDS["username"], "replacement-pass-2")
    user = repository.get_user(CREDS["username"])
    assert user is not None and verify_password("replacement-pass-2", user["password_hash"])
    assert not verify_password(CREDS["password"], user["password_hash"])


def test_local_password_reset_rejects_invalid_input_and_unknown_user(tmp_path):
    repository = SQLiteRepository(tmp_path / "t.db")
    repository.initialize()

    with pytest.raises(ValueError, match="Username"):
        reset_password(repository, "invalid username", "replacement-pass-2")
    with pytest.raises(ValueError, match="Password"):
        reset_password(repository, "unknown", "short")
    assert not reset_password(repository, "unknown", "replacement-pass-2")
